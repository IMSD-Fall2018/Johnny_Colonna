﻿using System.Collections;
using System.Collections.Generic;
using UnityEngine;

public class MainController : MonoBehaviour
{

    public Rotate rotatescript;
    public Spawner spawnerscript;
    public SimpleMove startandstop;
    public GameObject cylindertoinvis_obj;
    public MeshRenderer cylindertoinvis_mesh;
    public AudioSource musictoplay;
    public Camera camtocontrol;
    public Color backColor;
    public TextMesh text_obj;

    void Start()
    {
        
    }

    float textTimer = 0;
    void Update()
    {

        RotationControl();
        SpawnControl();
        MoveControl();
        CylinderControl();
        MusicControl();
        cambackgroundcontrol();
        textchange();

        textTimer += Time.deltaTime;
        if(textTimer >5)
        {
            text_obj.text = "Hi, how are you?";
            textTimer = 0;
        }
    }

    void RotationControl()
    {
        if (Input.GetKeyDown(KeyCode.Alpha1) && rotatescript.rotateSpeed == 0f)
        {
            rotatescript.rotateSpeed = 180f;
        }
        else if (Input.GetKeyDown(KeyCode.Alpha1) && rotatescript.rotateSpeed >= 1f)
        {
            rotatescript.rotateSpeed = 0f;
        }
    }
    void SpawnControl()
    {
        if (Input.GetKeyDown(KeyCode.Alpha2))
        {
            spawnerscript.SpawnObject();
        }
    }
    void MoveControl()
    {
        if (Input.GetKeyDown(KeyCode.Alpha3))
        {
            if (startandstop.moveSpeed == 0f)
            {
                startandstop.moveSpeed = 2f;
            }
            else if (startandstop.moveSpeed == 2f)
            {
                startandstop.moveSpeed = 0f;
            }
        }

    }
    void CylinderControl()
    {
        //if (Input.GetKeyDown(KeyCode.Alpha4) && cylindertoinvis_obj.activeSelf == true)
        //{
        //    cylindertoinvis_obj.SetActive(false);
        //}
        //else if (Input.GetKeyDown(KeyCode.Alpha4) && cylindertoinvis_obj.activeSelf == false)
        //{
        //    cylindertoinvis_obj.SetActive(true);
        //}
        if (Input.GetKeyDown(KeyCode.Alpha4) &&cylindertoinvis_mesh.enabled ==true)
        {
            cylindertoinvis_mesh.enabled =false;
        }
        else if (Input.GetKeyDown(KeyCode.Alpha4) && cylindertoinvis_mesh.enabled == false)
        {
            cylindertoinvis_mesh.enabled = true;
        }
    }
    void MusicControl()
    {
        if(Input.GetKeyDown(KeyCode.Alpha5) && musictoplay.isPlaying == false)
        {
            musictoplay.Play();
        }
        else if (Input.GetKeyDown(KeyCode.Alpha5) && musictoplay.isPlaying == true)
        {
            musictoplay.Stop();   
        }
    }

    bool backgroundFlag = true;

    void cambackgroundcontrol()
    {
        if(Input.GetKeyDown(KeyCode.Alpha6) && backgroundFlag == false)
        {
            camtocontrol.backgroundColor = backColor;
            backgroundFlag = true;
        }
        else if (Input.GetKeyDown(KeyCode.Alpha6) && backgroundFlag == true)
        {
            Color randColor = new Color();
            randColor.r = Random.Range(0, 1f);
            randColor.g = Random.Range(0, 1f);
            randColor.b = Random.Range(0, 1f);
            camtocontrol.backgroundColor = randColor;
            backgroundFlag = false;
        }
    }
    void textchange()
    {
        if (Input.GetKeyDown(KeyCode.Alpha7))
        {
            text_obj.text = "Hello World";
            text_obj.fontSize = 50;
        }
    }
}

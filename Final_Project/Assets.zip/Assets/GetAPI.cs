﻿using System.Collections;
using System.Collections.Generic;
using UnityEngine.Networking;
using UnityEngine;

public class GetAPI : MonoBehaviour {

    public string Spotify_ID = " ";
    private string url = "";

    public GameObject ballToSpawn;
    private float Num_Spheres;
    // Use this for initialization
    IEnumerator Start()
    {
        url = "https://api.spotify.com/v1/artists/" + Spotify_ID;
        UnityWebRequest wtest = UnityWebRequest.Get(url);
        wtest.SetRequestHeader("Authorization", "Bearer " + "BQD6Hiw79SH1kzJ55yaNlXc3051RvXj_z2Xn0zv9ZVRtiPpIdeoSegjFmoU5WU3pPeTbMGKtY1Swa-dznv3crjyq9CNPPpfiCozcjafTOt7tJAi6Llktd3aiT9CmqX8PI5h4FNKFpcIbP1h8hg");

        yield return wtest.SendWebRequest();

       // Debug.Log(wtest.downloadHandler.text);

        JSONObject tempData = new JSONObject(wtest.downloadHandler.text);

        JSONObject artistName = tempData["name"];
        JSONObject artistPop = tempData["popularity"];
        Num_Spheres = artistPop.n;
        Debug.Log("The popularity of " +artistName+ " is: " + artistPop.ToString()+" .");
        for (int i = 0; i < Num_Spheres; i++)
        {
            GameObject.Instantiate(ballToSpawn);
        }
        //for (int i = 0; i < 3; i++)
          //{
           // JSONObject artistNum = tempData["artists"][i]["name"];
           // Debug.Log(artistNum.ToString());
          //}
        //JSONObject artistNum1 = tempData["artists"][0];
        //Debug.Log(artistNum1.ToString());

        //JSONObject artistNum2 = tempData["artists"][1];
        //Debug.Log(artistNum2.ToString());

    }
}

﻿using System.Collections;
using System.Collections.Generic;
using UnityEngine;

public class madlibs : MonoBehaviour {

	public string[] userInputs = new string[10];
	

	// Use this for initialization
	void Start () {
        Debug.Log("Hello! Welcome to my madlibs game. Please input your words in the inspector window, " +
            "then click on the game view and press the 'R' key to see your story come to life in the console!");
    }
	
	// Update is called once per frame
	void Update () {
		if (Input.GetKeyDown(KeyCode.R))
        {
            finalString();
        }
	}
	void finalString()
	{
		string finalString = "";
        finalString += "One day, " + userInputs[0] + " and " + userInputs[1] + " went for a walk. ";
        finalString += "They had no idea where they were headed, and ended up in " +userInputs[2];
        finalString += ". They decided to go inside, and they couldn't believe what they saw! Inside was ";
        finalString += "a giant " + userInputs[3] + " " + userInputs[4] + "! They quickly realized they ";
        finalString += "were in great danger! " +userInputs[0] + " said, 'Quick! We need to " + userInputs[5];
        finalString += " out of here. It's the only way!' " + userInputs[1] + " turned to face " +userInputs[0];
        finalString += " and said, 'Are you crazy?? We need to " + userInputs[6] + ", everyone knows that's the";
        finalString += "only way to stop a " + userInputs[4] + "!' While the two were arguing, a second creature ";
        finalString += "emerged from under a " +userInputs[7]+ ". They heard a noise coming from the " +userInputs[7];
        finalString += " and " +userInputs[0] + " said, 'What? It can't be!? Is that a " + userInputs[8] + "?? ";
        finalString += "No! That's actually a " + userInputs[9] + "!! THE SWORN ENEMY OF THE " + userInputs[4] + "s!";
        finalString += "The two watched as the " + userInputs[9] + " and the " + userInputs[4] + " fought it out. ";
        finalString += "The fight eventually ended with the " + userInputs[9] +" victorious, so " + userInputs[0] + " and ";
        finalString += userInputs[1] + " ran out of the " +userInputs[2]+ ". They both agreed to never speak about it again.";
        Debug.Log(finalString);
    }
}

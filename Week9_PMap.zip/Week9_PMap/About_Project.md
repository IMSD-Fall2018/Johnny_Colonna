# Projection Mapping Project

Team:
Oleg Ligay
Bryan Soasti
Johnny Colonna
Kiara Wright

We took a box and filled it with projection cubes. In order to contain cubes we put invisible walls and we put a black floor underneath our box. As for user input we used key presses to delete the cubes that fall out of the main box. Up arrow moves a "killzone" to collide with the cubes and destroys them upon impact. And, down arrow resets the "killzone". We also added sound to play on collision of the cubes.
